BAU DVM Cover Page Generator — H DEFAULT

Group H is now the default. G remains available as an alternative.
